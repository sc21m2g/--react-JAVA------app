package com.example.scooterrent.config;

import com.example.scooterrent.entity.Role;
import com.example.scooterrent.entity.User;
import com.example.scooterrent.repository.RoleRepository;
import com.example.scooterrent.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import com.example.scooterrent.entity.Scooter;
import com.example.scooterrent.enums.ScooterStatus;
import com.example.scooterrent.repository.ScooterRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;
import java.util.Arrays;

@Component
@Configuration
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
        try {
            logger.info("Initializing default roles...");
            
            // 使用原生SQL查询检查角色是否存在
            createRoleIfNotExists("ROLE_USER", "Regular user role");
            createRoleIfNotExists("ROLE_ADMIN", "Administrator role");
            createRoleIfNotExists("ROLE_DISCOUNT", "Student/Elderly Discount role");
            
            // 创建管理员用户
            if (!userRepository.existsByUsername("admin")) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setEmail("admin@example.com");
                Role adminRole = roleRepository.findByName("ROLE_ADMIN")
                    .orElseThrow(() -> new RuntimeException("Admin role not found"));
                admin.setRole(adminRole);
                userRepository.save(admin);
            }

            // 创建测试用户
            if (!userRepository.existsByUsername("user")) {
                User user = new User();
                user.setUsername("user");
                user.setPassword(passwordEncoder.encode("user123"));
                user.setEmail("user@example.com");
                Role userRole = roleRepository.findByName("ROLE_USER")
                    .orElseThrow(() -> new RuntimeException("User role not found"));
                user.setRole(userRole);
                userRepository.save(user);
            }
            
            logger.info("Data initialization completed successfully");
        } catch (Exception e) {
            logger.error("Error during data initialization: " + e.getMessage(), e);
        }
    }
    
    private void createRoleIfNotExists(String roleName, String description) {
        try {
            // 使用原生SQL查询检查角色是否存在
            List<Map<String, Object>> roles = jdbcTemplate.queryForList(
                    "SELECT * FROM roles WHERE name = ?", 
                    roleName);
            
            if (roles.isEmpty()) {
                logger.info("Creating role: {}", roleName);
                Role role = new Role();
                role.setName(roleName);
                role.setDescription(description);
                roleRepository.save(role);
                logger.info("Created role: {}", roleName);
            } else {
                logger.info("Role {} already exists", roleName);
            }
        } catch (Exception e) {
            logger.error("Error creating role {}: {}", roleName, e.getMessage(), e);
        }
    }

    @Bean
    CommandLineRunner initDatabase(ScooterRepository scooterRepository) {
        return args -> {
            if (scooterRepository.count() == 0) {
                initializeScooters(scooterRepository);
            }
        };
    }

    private void initializeScooters(ScooterRepository scooterRepository) {
        Scooter scooter1 = new Scooter();
        scooter1.setModel("Xiaomi Pro 2");
        scooter1.setSerialNumber("XP2-2025-001");
        scooter1.setStatus(ScooterStatus.AVAILABLE);
        scooter1.setPricePerHour(15.0);
        scooter1.setPricePerFourHours(50.0);
        scooter1.setPricePerDay(100.0);
        scooter1.setPricePerWeek(500.0);
        scooter1.setBatteryLevel(85);
        scooter1.setLocation("春熙路");
        scooter1.setLatitude(30.6571);
        scooter1.setLongitude(104.0870);
        scooter1.setImageUrl("/images/scooter1.jpg");

        Scooter scooter2 = new Scooter();
        scooter2.setModel("Ninebot Max");
        scooter2.setSerialNumber("NBM-2025-002");
        scooter2.setStatus(ScooterStatus.AVAILABLE);
        scooter2.setPricePerHour(18.0);
        scooter2.setPricePerFourHours(60.0);
        scooter2.setPricePerDay(120.0);
        scooter2.setPricePerWeek(600.0);
        scooter2.setBatteryLevel(70);
        scooter2.setLocation("太古里");
        scooter2.setLatitude(30.6574);
        scooter2.setLongitude(104.0885);
        scooter2.setImageUrl("/images/scooter2.jpg");

        Scooter scooter3 = new Scooter();
        scooter3.setModel("Segway ES4");
        scooter3.setSerialNumber("SES4-2025-003");
        scooter3.setStatus(ScooterStatus.AVAILABLE);
        scooter3.setPricePerHour(20.0);
        scooter3.setPricePerFourHours(70.0);
        scooter3.setPricePerDay(140.0);
        scooter3.setPricePerWeek(700.0);
        scooter3.setBatteryLevel(45);
        scooter3.setLocation("宽窄巷子");
        scooter3.setLatitude(30.6705);
        scooter3.setLongitude(104.0647);
        scooter3.setImageUrl("/images/scooter3.jpg");

        Scooter scooter4 = new Scooter();
        scooter4.setModel("Xiaomi Essential");
        scooter4.setSerialNumber("XE-2025-004");
        scooter4.setStatus(ScooterStatus.AVAILABLE);
        scooter4.setPricePerHour(12.0);
        scooter4.setPricePerFourHours(40.0);
        scooter4.setPricePerDay(80.0);
        scooter4.setPricePerWeek(400.0);
        scooter4.setBatteryLevel(92);
        scooter4.setLocation("天府广场");
        scooter4.setLatitude(30.6571);
        scooter4.setLongitude(104.0657);
        scooter4.setImageUrl("/images/scooter4.jpg");

        Scooter scooter5 = new Scooter();
        scooter5.setModel("Dualtron Eagle");
        scooter5.setSerialNumber("DE-2025-005");
        scooter5.setStatus(ScooterStatus.AVAILABLE);
        scooter5.setPricePerHour(25.0);
        scooter5.setPricePerFourHours(80.0);
        scooter5.setPricePerDay(160.0);
        scooter5.setPricePerWeek(800.0);
        scooter5.setBatteryLevel(65);
        scooter5.setLocation("锦里古街");
        scooter5.setLatitude(30.6421);
        scooter5.setLongitude(104.0471);
        scooter5.setImageUrl("/images/scooter5.jpg");

        List<Scooter> scooters = Arrays.asList(scooter1, scooter2, scooter3, scooter4, scooter5);
        scooterRepository.saveAll(scooters);
    }
} 