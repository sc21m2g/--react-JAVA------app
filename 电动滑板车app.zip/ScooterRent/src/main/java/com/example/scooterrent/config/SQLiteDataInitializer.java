package com.example.scooterrent.config;

import com.example.scooterrent.entity.Role;
import com.example.scooterrent.entity.User;
import com.example.scooterrent.repository.RoleRepository;
import com.example.scooterrent.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * 应用启动时初始化基础数据
 */
@Component
public class SQLiteDataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(SQLiteDataInitializer.class);

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public SQLiteDataInitializer(UserRepository userRepository, RoleRepository roleRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        try {
            // 创建角色
            if (roleRepository.count() == 0) {
                Role adminRole = new Role();
                adminRole.setName("ROLE_ADMIN");
                adminRole.setDescription("Administrator role");
                roleRepository.save(adminRole);

                Role userRole = new Role();
                userRole.setName("ROLE_USER");
                userRole.setDescription("User role");
                roleRepository.save(userRole);

                Role discountRole = new Role();
                discountRole.setName("ROLE_DISCOUNT");
                discountRole.setDescription("Student/Elderly Discount role");
                roleRepository.save(discountRole);
            }

            // 创建管理员用户
            if (!userRepository.existsByUsername("admin")) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setEmail("admin@example.com");
                Role adminRole = roleRepository.findByName("ROLE_ADMIN")
                    .orElseThrow(() -> new RuntimeException("Admin role not found"));
                admin.setRole(adminRole);
                userRepository.save(admin);
            }

            // 创建测试用户
            if (!userRepository.existsByUsername("user")) {
                User user = new User();
                user.setUsername("user");
                user.setPassword(passwordEncoder.encode("user123"));
                user.setEmail("user@example.com");
                Role userRole = roleRepository.findByName("ROLE_USER")
                    .orElseThrow(() -> new RuntimeException("User role not found"));
                user.setRole(userRole);
                userRepository.save(user);
            }

            logger.info("SQLite data initialization completed successfully");
        } catch (Exception e) {
            logger.error("Error during SQLite data initialization: ", e);
        }
    }
} 