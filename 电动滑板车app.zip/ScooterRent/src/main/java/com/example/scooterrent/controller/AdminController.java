package com.example.scooterrent.controller;

import com.example.scooterrent.dto.RentalPlanStatsDTO;
import com.example.scooterrent.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class AdminController {
    
    @Autowired
    private RentalService rentalService;

    @GetMapping("/admin/rental-plan-stats")
    public List<RentalPlanStatsDTO> getRentalPlanStats() {
        return rentalService.getRentalPlanStats();
    }
}
