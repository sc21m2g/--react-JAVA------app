package com.example.scooterrent.controller;

import com.example.scooterrent.dto.IncomeAnalysisDTO;
import com.example.scooterrent.service.IncomeAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/income-analysis")
public class IncomeAnalysisController {

    @Autowired
    private IncomeAnalysisService incomeAnalysisService;

    @GetMapping("/weekly")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<IncomeAnalysisDTO> getWeeklyIncomeAnalysis() {
        IncomeAnalysisDTO analysis = incomeAnalysisService.getWeeklyIncomeAnalysis();
        return ResponseEntity.ok(analysis);
    }
} 