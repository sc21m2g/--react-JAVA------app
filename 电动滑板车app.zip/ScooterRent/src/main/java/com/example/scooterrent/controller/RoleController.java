package com.example.scooterrent.controller;

import com.example.scooterrent.entity.Role;
import com.example.scooterrent.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/roles")
@CrossOrigin(origins = "*")
public class RoleController {

    private static final Logger logger = LoggerFactory.getLogger(RoleController.class);

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Role>> getAllRoles() {
        logger.info("获取所有角色");
        List<Role> roles = roleRepository.findAll();
        return ResponseEntity.ok(roles);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Role> getRoleById(@PathVariable Long id) {
        logger.info("通过ID获取角色: {}", id);
        Optional<Role> roleOptional = roleRepository.findById(id);
        if (!roleOptional.isPresent()) {
            logger.warn("未找到ID为 {} 的角色", id);
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(roleOptional.get());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Role> createRole(@RequestBody Role role) {
        logger.info("创建新角色: {}", role.getName());
        
        // 检查角色名是否已存在
        if (roleRepository.existsByName(role.getName())) {
            logger.warn("角色名 {} 已存在", role.getName());
            return ResponseEntity.badRequest().build();
        }
        
        Role savedRole = roleRepository.save(role);
        logger.info("角色创建成功: {}, ID: {}", savedRole.getName(), savedRole.getId());
        return ResponseEntity.ok(savedRole);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Role> updateRole(@PathVariable Long id, @RequestBody Role role) {
        logger.info("更新ID为 {} 的角色", id);
        
        if (!roleRepository.existsById(id)) {
            logger.warn("未找到ID为 {} 的角色", id);
            return ResponseEntity.notFound().build();
        }
        
        role.setId(id);
        Role updatedRole = roleRepository.save(role);
        logger.info("角色更新成功: {}", updatedRole.getName());
        return ResponseEntity.ok(updatedRole);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteRole(@PathVariable Long id) {
        logger.info("删除ID为 {} 的角色", id);
        
        if (!roleRepository.existsById(id)) {
            logger.warn("未找到ID为 {} 的角色", id);
            return ResponseEntity.notFound().build();
        }
        
        roleRepository.deleteById(id);
        logger.info("角色删除成功");
        return ResponseEntity.ok().build();
    }

    @GetMapping("/init")
    // 允许未授权访问
    public ResponseEntity<String> initDefaultRoles() {
        logger.info("初始化默认角色");
        
        // 创建默认用户角色
        if (!roleRepository.existsByName("ROLE_USER")) {
            Role userRole = new Role();
            userRole.setName("ROLE_USER");
            userRole.setDescription("Default user role");
            roleRepository.save(userRole);
            logger.info("创建了默认用户角色");
        }
        
        // 创建管理员角色
        if (!roleRepository.existsByName("ROLE_ADMIN")) {
            Role adminRole = new Role();
            adminRole.setName("ROLE_ADMIN");
            adminRole.setDescription("Administrator role");
            roleRepository.save(adminRole);
            logger.info("创建了管理员角色");
        }
        
        return ResponseEntity.ok("默认角色初始化成功");
    }
} 