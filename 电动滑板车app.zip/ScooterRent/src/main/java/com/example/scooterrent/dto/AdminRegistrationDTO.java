package com.example.scooterrent.dto;

import lombok.Data;

@Data
public class AdminRegistrationDTO {
    private String username;
    private String password;
    private String email;
    private String phone;
    private String adminSecret; // Secret key for admin registration
} 