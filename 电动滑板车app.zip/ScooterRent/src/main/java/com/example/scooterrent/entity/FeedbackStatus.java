package com.example.scooterrent.entity;

public enum FeedbackStatus {
    PENDING,        // 待处理
    IN_PROGRESS,    // 处理中
    RESOLVED,       // 已解决
    CLOSED          // 已关闭
} 