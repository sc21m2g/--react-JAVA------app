package com.example.scooterrent.entity;

public enum OrderStatus {
    PENDING,    // 待确认
    ACTIVE,     // 进行中
    COMPLETED,  // 已完成
    CANCELLED,  // 已取消
    EXTENDED,   // 已延长
    CONFIRMED   // 已确认
} 