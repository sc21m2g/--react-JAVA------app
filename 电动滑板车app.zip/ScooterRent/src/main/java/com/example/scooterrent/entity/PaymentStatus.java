package com.example.scooterrent.entity;

public enum PaymentStatus {
    PENDING,    // 待支付
    COMPLETED,  // 已完成
    FAILED,     // 失败
    REFUNDED,   // 已退款
    CANCELLED   // 已取消
} 