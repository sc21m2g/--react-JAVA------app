package com.example.scooterrent.entity;

public enum ScooterStatus {
    AVAILABLE,    // 可用
    RENTED,      // 已租用
    MAINTENANCE, // 维护中
    OUT_OF_SERVICE
} 