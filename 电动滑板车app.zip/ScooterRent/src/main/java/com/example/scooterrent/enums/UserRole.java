package com.example.scooterrent.enums;

public enum UserRole {
    ROLE_USER,    // Regular user
    ROLE_ADMIN,    // Administrator
    ROLE_DISCOUNT // Student/Elderly Discount
} 