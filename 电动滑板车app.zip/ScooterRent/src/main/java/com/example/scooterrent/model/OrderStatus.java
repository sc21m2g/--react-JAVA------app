package com.example.scooterrent.model;

public enum OrderStatus {
    PENDING,     // 待支付
    PAID,        // 已支付
    COMPLETED,   // 已完成
    CANCELLED    // 已取消
} 