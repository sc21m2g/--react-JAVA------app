package com.example.scooterrent.model;

public enum ScooterStatus {
    AVAILABLE,    // 可用
    IN_USE,       // 使用中
    MAINTENANCE   // 维护中
} 