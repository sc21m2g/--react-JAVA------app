package com.example.scooterrent.model.enums;

public enum PaymentStatus {
    PENDING,        // Pending
    SUCCESS,        // Success
    FAILED          // Failed
} 