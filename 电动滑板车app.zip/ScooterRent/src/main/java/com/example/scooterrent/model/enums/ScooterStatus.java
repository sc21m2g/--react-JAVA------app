package com.example.scooterrent.model.enums;

public enum ScooterStatus {
    AVAILABLE,       // Available
    RENTED,         // Rented
    MAINTENANCE,    // Under maintenance
    BROKEN,         // Broken
    RESERVED        // Reserved
} 