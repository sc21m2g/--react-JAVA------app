package com.example.scooterrent.service;

import com.example.scooterrent.dto.LoginRequestDTO;
import com.example.scooterrent.dto.LoginResponseDTO;
import com.example.scooterrent.dto.RegisterRequestDTO;

public interface AuthService {
    LoginResponseDTO register(RegisterRequestDTO request);
    LoginResponseDTO login(LoginRequestDTO request);
} 