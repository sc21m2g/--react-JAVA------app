package com.example.scooterrent.service;

import com.example.scooterrent.dto.FeedbackDTO;
import com.example.scooterrent.dto.FeedbackRequestDTO;
import com.example.scooterrent.enums.FeedbackStatus;
import java.util.List;

public interface FeedbackService {
    List<FeedbackDTO> getAllFeedbacks();
    FeedbackDTO createFeedback(FeedbackRequestDTO requestDTO);
    FeedbackDTO createFeedbackForPayment(Long paymentId, FeedbackRequestDTO requestDTO);
    FeedbackDTO getFeedbackById(Integer id);
    List<FeedbackDTO> getFeedbacksByUsername(String username);
    List<FeedbackDTO> getFeedbacksByStatus(FeedbackStatus status);
    List<FeedbackDTO> getFeedbacksByType(String type);
    FeedbackDTO updateFeedbackStatus(Integer id, FeedbackStatus status);
    FeedbackDTO addAdminResponse(Integer id, String response);
    void deleteFeedback(Integer id);
} 