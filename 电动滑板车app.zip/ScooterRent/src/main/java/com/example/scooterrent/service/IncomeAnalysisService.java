package com.example.scooterrent.service;

import com.example.scooterrent.dto.IncomeAnalysisDTO;
import com.example.scooterrent.entity.Payment;
import com.example.scooterrent.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IncomeAnalysisService {

    @Autowired
    private PaymentRepository paymentRepository;

    public IncomeAnalysisDTO getWeeklyIncomeAnalysis() {
        LocalDateTime endDate = LocalDateTime.now();
        LocalDateTime startDate = endDate.minus(7, ChronoUnit.DAYS);

        List<Payment> payments = paymentRepository.findByPaymentTimeBetween(startDate, endDate);

        Map<String, BigDecimal> incomeByType = new HashMap<>();
        Map<String, BigDecimal> dailyIncome = new HashMap<>();
        Map<String, Map<String, BigDecimal>> dailyIncomeByType = new HashMap<>();

        for (Payment payment : payments) {
            String rentalType = getRentalType(payment);
            BigDecimal amount = payment.getAmount();
            String date = payment.getPaymentTime().toLocalDate().toString();

            // 按类型统计收入
            incomeByType.merge(rentalType, amount, BigDecimal::add);

            // 按天统计总收入
            dailyIncome.merge(date, amount, BigDecimal::add);

            // 按天和类型统计收入
            dailyIncomeByType.computeIfAbsent(date, k -> new HashMap<>())
                    .merge(rentalType, amount, BigDecimal::add);
        }

        return new IncomeAnalysisDTO(incomeByType, dailyIncome, dailyIncomeByType);
    }

    private String getRentalType(Payment payment) {
        if (payment.getRental() != null && payment.getRental().getPlan() != null) {
            String plan = payment.getRental().getPlan().toUpperCase();
            switch (plan) {
                case "HOURLY":
                    return "1hr";
                case "FOUR_HOURS":
                    return "4hr";
                case "DAILY":
                    return "day";
                case "WEEKLY":
                    return "week";
                default:
                    return "other";
            }
        }
        return "other";
    }
} 