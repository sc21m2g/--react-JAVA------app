package com.example.scooterrent.service;

import com.example.scooterrent.dto.OrderDTO;
import com.example.scooterrent.enums.OrderStatus;
import java.time.LocalDateTime;
import java.util.List;

public interface OrderService {
    /**
     * 创建订单
     */
    OrderDTO createOrder(OrderDTO orderDTO);
    
    /**
     * 通过ID获取订单
     */
    OrderDTO getOrderById(Long id);
    
    /**
     * 获取用户的所有订单
     */
    List<OrderDTO> getAllOrders();
    
    /**
     * 获取用户的所有订单
     */
    List<OrderDTO> getOrdersByUsername(String username);
    
    /**
     * 获取特定状态的所有订单
     */
    List<OrderDTO> getOrdersByStatus(OrderStatus status);
    
    /**
     * 更新订单状态
     */
    OrderDTO updateOrderStatus(Long id, OrderStatus status);
    
    /**
     * 取消订单
     */
    void deleteOrder(Long id);
    
    /**
     * 获取特定日期范围内的所有订单
     */
    List<OrderDTO> getOrdersByDateRange(LocalDateTime start, LocalDateTime end);
    
    /**
     * 获取用户在特定日期范围内的所有订单
     */
    List<OrderDTO> getUserOrdersByDateRange(String username, LocalDateTime start, LocalDateTime end);
} 