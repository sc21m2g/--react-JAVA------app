package com.example.scooterrent.service;

import com.example.scooterrent.entity.Payment;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface PaymentService {
    @Transactional
    Payment createPayment(Long rentalId, BigDecimal amount, String paymentMethod, String transactionId);

    Payment getPaymentById(Long id);

    List<Payment> getPaymentsByRentalId(Long rentalId);

    @Transactional
    Payment updatePaymentStatus(Long id, String status);

    List<Payment> getPaymentsByStatus(String status);

    List<Payment> getPaymentsByDateRange(LocalDateTime start, LocalDateTime end);
} 