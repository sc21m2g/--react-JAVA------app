package com.example.scooterrent.service;

import com.example.scooterrent.dto.RentalDTO;
import com.example.scooterrent.dto.RentalPlanStatsDTO;
import java.util.List;

public interface RentalService {
    List<RentalDTO> getUserRentals(String username);
    RentalDTO getRentalById(Long id);
    RentalDTO createRental(String username, Long scooterId, RentalDTO rentalDetails);
    RentalDTO endRental(Long id, RentalDTO endDetails);
    RentalDTO extendRental(Long id, Integer additionalHours);
    RentalDTO cancelRental(Long id);
    double calculateRentalCost(Long rentalId, String startTime, String endTime, String plan);
    List<RentalPlanStatsDTO> getRentalPlanStats();
} 