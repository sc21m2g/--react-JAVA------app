package com.example.scooterrent.service;

import com.example.scooterrent.dto.ScooterDTO;
import com.example.scooterrent.enums.ScooterStatus;
import java.time.LocalDateTime;
import java.util.List;
import com.example.scooterrent.dto.ScooterStatsDTO;

public interface ScooterService {
    ScooterDTO createScooter(ScooterDTO scooterDTO);
    ScooterDTO getScooterById(Long id);
    List<ScooterDTO> getAllScooters();
    List<ScooterDTO> getAvailableScooters();
    void deleteScooter(Long id);
    ScooterDTO updateScooterPrice(Long id, Double pricePerHour, Double pricePerFourHours, Double pricePerDay, Double pricePerWeek);
    ScooterDTO updateScooter(Long id, ScooterDTO scooterDTO);
    List<ScooterStatsDTO> getScooterStats();
} 