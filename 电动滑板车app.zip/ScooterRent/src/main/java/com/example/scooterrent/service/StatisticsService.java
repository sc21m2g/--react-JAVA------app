package com.example.scooterrent.service;

import java.util.List;
import java.util.Map;

public interface StatisticsService {
    List<Map<String, Object>> getUserRoleDistribution();
    List<Map<String, Object>> getDailyRevenue();
    Map<String, Object> getDashboardStats();
}
