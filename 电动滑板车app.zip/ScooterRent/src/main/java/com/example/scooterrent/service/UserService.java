package com.example.scooterrent.service;

import com.example.scooterrent.dto.LoginDTO;
import com.example.scooterrent.dto.UserDTO;
import com.example.scooterrent.dto.UserRegistrationDTO;
import com.example.scooterrent.dto.AdminRegistrationDTO;
import com.example.scooterrent.dto.LoginResponseDTO;
import java.util.List;

public interface UserService {
    UserDTO register(UserRegistrationDTO registrationDTO);
    UserDTO registerAdmin(AdminRegistrationDTO registrationDTO);
    LoginResponseDTO login(LoginDTO loginDTO);
    
    // 保留原方法但标记为已弃用
    @Deprecated
    UserDTO getUserById(Integer id);
    
    // 添加新方法
    UserDTO getUserByUsername(String username);
    
    // 获取所有用户
    List<UserDTO> getAllUsers();
    
    // 更新用户方法
    UserDTO updateUser(String username, UserDTO userDTO);
    
    // 保留原方法但标记为已弃用
    @Deprecated
    void deleteUser(Integer id);
    
    // 删除用户方法
    void deleteUser(String username);
    
    // 设置用户角色
    void setUserRole(String username, String roleName);
} 