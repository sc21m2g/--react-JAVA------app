package com.example.scooterrent.service.impl;

import com.example.scooterrent.dto.LoginRequestDTO;
import com.example.scooterrent.dto.LoginResponseDTO;
import com.example.scooterrent.dto.RegisterRequestDTO;
import com.example.scooterrent.entity.Role;
import com.example.scooterrent.entity.User;
import com.example.scooterrent.repository.RoleRepository;
import com.example.scooterrent.repository.UserRepository;
import com.example.scooterrent.service.AuthService;
import com.example.scooterrent.util.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Override
    public LoginResponseDTO register(RegisterRequestDTO request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        Role userRole = roleRepository.findByName("ROLE_USER")
            .orElseThrow(() -> new RuntimeException("User role not found"));
        user.setRole(userRole);

        userRepository.save(user);

        String token = jwtTokenUtil.generateToken(user.getUsername());
        return new LoginResponseDTO(token, user.getUsername(), user.getRole().getName(), user.getEmail(), user.getPhone());
    }

    @Override
    public LoginResponseDTO login(LoginRequestDTO request) {
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        User user = userRepository.findByUsername(request.getUsername())
            .orElseThrow(() -> new RuntimeException("User not found"));

        String token = jwtTokenUtil.generateToken(user.getUsername());
        return new LoginResponseDTO(token, user.getUsername(), user.getRole().getName(), user.getEmail(), user.getPhone());
    }
} 