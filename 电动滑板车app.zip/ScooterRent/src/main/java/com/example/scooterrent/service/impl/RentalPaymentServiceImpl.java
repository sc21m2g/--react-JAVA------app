package com.example.scooterrent.service.impl;

import com.example.scooterrent.entity.Payment;
import com.example.scooterrent.entity.Rental;
import com.example.scooterrent.repository.PaymentRepository;
import com.example.scooterrent.repository.RentalRepository;
import com.example.scooterrent.service.RentalPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class RentalPaymentServiceImpl implements RentalPaymentService {

    private static final Logger logger = LoggerFactory.getLogger(RentalPaymentServiceImpl.class);

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private RentalRepository rentalRepository;

    @Override
    @Transactional
    public Payment createPayment(Long rentalId, BigDecimal amount, String paymentMethod, String email, String transactionId) {
        try {
            logger.info("Creating payment for rental {} with amount {} and method {} and email {}", 
                rentalId, amount, paymentMethod, email);

            Rental rental = rentalRepository.findById(rentalId)
                    .orElseThrow(() -> new RuntimeException("Rental not found with id: " + rentalId));

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                throw new RuntimeException("Payment amount must be greater than zero");
            }

            Payment payment = new Payment();
            payment.setRental(rental);
            payment.setAmount(amount);
            payment.setPaymentMethod(paymentMethod);
            payment.setTransactionId(transactionId);
            payment.setPaymentTime(LocalDateTime.now());
            payment.setEmail(email);
            payment.setStatus("COMPLETED");

            Payment savedPayment = paymentRepository.save(payment);
            logger.info("Payment created successfully with id: {}", savedPayment.getId());
            return savedPayment;
        } catch (Exception e) {
            logger.error("Error creating payment for rental {}: {}", rentalId, e.getMessage(), e);
            throw new RuntimeException("Error creating payment: " + e.getMessage());
        }
    }

    @Override
    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }

    @Override
    public List<Payment> getPaymentsByRentalId(Long rentalId) {
        return paymentRepository.findByRentalId(rentalId);
    }

    @Override
    @Transactional
    public Payment updatePaymentStatus(Long id, String status) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        
        payment.setStatus(status);
        return paymentRepository.save(payment);
    }

    @Override
    public List<Payment> getPaymentsByStatus(String status) {
        return paymentRepository.findByStatus(status);
    }

    @Override
    public List<Payment> getPaymentsByDateRange(LocalDateTime start, LocalDateTime end) {
        return paymentRepository.findByPaymentTimeBetween(start, end);
    }
} 