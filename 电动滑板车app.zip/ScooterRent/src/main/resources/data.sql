-- 角色初始化
INSERT OR IGNORE INTO roles (id, name, description, created_at, updated_at)
VALUES (1, 'ROLE_USER', '普通用户角色', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT OR IGNORE INTO roles (id, name, description, created_at, updated_at)
VALUES (2, 'ROLE_ADMIN', '管理员角色', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- 如果有角色ID为3的引用，但角色不存在，创建一个备用角色
INSERT OR IGNORE INTO roles (id, name, description, created_at, updated_at)
VALUES (4, 'ROLE_USER', '备用普通用户角色', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP); 