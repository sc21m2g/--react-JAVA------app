-- 创建角色表
CREATE TABLE IF NOT EXISTS roles (
                                     id INTEGER PRIMARY KEY AUTOINCREMENT,
                                     name TEXT NOT NULL UNIQUE,
                                     description TEXT,
                                     created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                     updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 插入默认角色
INSERT OR IGNORE INTO roles (name, description) VALUES
('ROLE_USER', 'Regular User'),
('ROLE_ADMIN', 'Administrator');

-- 创建用户表
CREATE TABLE IF NOT EXISTS users (
                                     username TEXT PRIMARY KEY NOT NULL COLLATE NOCASE,
                                     password TEXT NOT NULL,
                                     email TEXT NOT NULL UNIQUE,
                                     phone TEXT,
                                     role_id INTEGER NOT NULL,
                                     created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                     updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                     FOREIGN KEY (role_id) REFERENCES roles(id)
    );

-- 创建滑板车表
CREATE TABLE IF NOT EXISTS scooters (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        serial_number TEXT NOT NULL UNIQUE,
                                        model TEXT NOT NULL,
                                        status TEXT NOT NULL,
                                        price_per_hour REAL NOT NULL,
                                        price_per_four_hours REAL NOT NULL,
                                        price_per_day REAL NOT NULL,
                                        price_per_week REAL NOT NULL,
                                        battery_level INTEGER NOT NULL,
                                        location TEXT,
                                        latitude REAL,
                                        longitude REAL,
                                        image_url TEXT,
                                        last_maintenance_date DATETIME,
                                        next_maintenance_date DATETIME,
                                        maintenance_notes TEXT,
                                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 创建订单表
CREATE TABLE IF NOT EXISTS orders (
                                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                                      user_id INTEGER NOT NULL,
                                      scooter_id INTEGER NOT NULL,
                                      start_time DATETIME NOT NULL,
                                      end_time DATETIME NOT NULL,
                                      total_hours INTEGER NOT NULL,
                                      total_amount REAL NOT NULL,
                                      status TEXT NOT NULL,
                                      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                      FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (scooter_id) REFERENCES scooters(id)
    );

-- 创建支付表
CREATE TABLE IF NOT EXISTS payments (
                                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                                        order_id INTEGER NOT NULL UNIQUE,
                                        amount REAL NOT NULL,
                                        payment_method TEXT,
                                        status TEXT NOT NULL,
                                        transaction_id TEXT UNIQUE,
                                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                        FOREIGN KEY (order_id) REFERENCES orders(id)
    );

-- 创建反馈表
CREATE TABLE IF NOT EXISTS feedbacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_username TEXT NOT NULL,
    payment_id INTEGER,
    content TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL,
    admin_response TEXT,
    rating INTEGER,
    contact_info TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    FOREIGN KEY (user_username) REFERENCES users(username),
    FOREIGN KEY (payment_id) REFERENCES payments(id)
);


-- 创建索引
CREATE INDEX IF NOT EXISTS idx_roles_name ON roles(name);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role_id ON users(role_id);
CREATE INDEX IF NOT EXISTS idx_scooters_status ON scooters(status);
CREATE INDEX IF NOT EXISTS idx_scooters_serial_number ON scooters(serial_number);
CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_scooter_id ON orders(scooter_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_payments_order_id ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_transaction_id ON payments(transaction_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_user_username ON feedbacks(user_username);
CREATE INDEX IF NOT EXISTS idx_feedbacks_status ON feedbacks(status);
CREATE INDEX IF NOT EXISTS idx_feedbacks_type ON feedbacks(type);