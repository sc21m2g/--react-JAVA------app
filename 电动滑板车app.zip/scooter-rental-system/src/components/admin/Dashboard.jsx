import React, { useState, useEffect } from 'react';  
import { Container, Row, Col, Card } from 'react-bootstrap';  
import { FaUsers, FaMoneyBillWave } from 'react-icons/fa';  
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';  
import adminService from '../../services/admin.service';  

const Dashboard = () => {  
  const [stats, setStats] = useState({  
    totalUsers: 0,  
    totalOrders: 0
  });  
  
  const [userRoles, setUserRoles] = useState([]);  
  const [dailyRevenue, setDailyRevenue] = useState([]);  
  const [rentalPlanStats, setRentalPlanStats] = useState([]);  
  const [isLoading, setIsLoading] = useState(true);  
  const [error, setError] = useState(null);
  
  const COLORS = ['#4CAF50', '#2196F3', '#FFC107'];  

  useEffect(() => {  
    const fetchDashboardData = async () => {  
      try {  
        setIsLoading(true);  
        setError(null);
        
        // Fetch user role distribution
        const roleData = await adminService.getUserRoleDistribution();
        setUserRoles(roleData);
        
        // Fetch daily revenue
        const revenueData = await adminService.getDailyRevenue();
        setDailyRevenue(revenueData);
        
        // Fetch total stats
        const statsData = await adminService.getDashboardStats();
        setStats(statsData);
        
        // Fetch rental plan stats
        const planStats = await adminService.getRentalPlanStats();
        setRentalPlanStats(planStats);
        
        setIsLoading(false);  
      } catch (error) {  
        console.error('Failed to fetch dashboard data:', error);  
        setError(error.message || 'Failed to fetch data, please try again later');
        setIsLoading(false);  
      }  
    };  
    
    fetchDashboardData();  
  }, []);  
  
  if (isLoading) {
    return (
      <Container fluid className="py-4">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading data...</p>
        </div>
      </Container>
    );
  }

  if (error) {
    return (
      <Container fluid className="py-4">
        <div className="alert alert-danger" role="alert">
          <h4 className="alert-heading">Loading Failed</h4>
          <p>{error}</p>
          <hr />
          <p className="mb-0">Please check your network connection or try again later.</p>
        </div>
      </Container>
    );
  }

  return (  
    <Container fluid className="py-4">  
      <Row className="mb-4">  
        <Col>  
          <h2 className="mb-1">Admin Dashboard</h2>  
          <p className="text-muted">System Overview and Statistics</p>  
        </Col>  
      </Row>  
      
      {/* Statistics Cards */}
      <Row className="g-3 mb-4">  
        <Col md={6}>  
          <Card className="h-100 border-0 shadow-sm">  
            <Card.Body>  
              <div className="d-flex justify-content-between align-items-center">  
                <div>  
                  <h6 className="text-muted mb-2">Total Users</h6>  
                  <h3 className="mb-0">{stats.totalUsers}</h3>  
                </div>  
                <div className="icon-bg bg-primary-light">  
                  <FaUsers className="text-primary" size={24} />  
                </div>  
              </div>  
            </Card.Body>  
          </Card>  
        </Col>  
        
        <Col md={6}>  
          <Card className="h-100 border-0 shadow-sm">  
            <Card.Body>  
              <div className="d-flex justify-content-between align-items-center">  
                <div>  
                  <h6 className="text-muted mb-2">Total Orders</h6>  
                  <h3 className="mb-0">{stats.totalOrders}</h3>  
                </div>  
                <div className="icon-bg bg-success-light">  
                  <FaMoneyBillWave className="text-success" size={24} />  
                </div>  
              </div>  
            </Card.Body>  
          </Card>  
        </Col>  
      </Row>  
      
      {/* Charts */}
      <Row className="mb-4">  
        <Col xl={6}>  
          <Card className="border-0 shadow-sm mb-4">  
            <Card.Header className="bg-white border-0 pt-4 pb-0">  
              <h5 className="mb-0">User Role Distribution</h5>  
            </Card.Header>  
            <Card.Body className="d-flex flex-column align-items-center">  
              <ResponsiveContainer width="100%" height={300}>  
                <PieChart>  
                  <Pie  
                    data={userRoles}  
                    cx="50%"  
                    cy="50%"  
                    labelLine={false}  
                    outerRadius={100}  
                    fill="#8884d8"  
                    dataKey="value"  
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}  
                  >  
                    {userRoles.map((entry, index) => (  
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />  
                    ))}  
                  </Pie>  
                  <Tooltip formatter={(value, name) => [value, name]} />  
                </PieChart>  
              </ResponsiveContainer>  
              
              <div className="w-100 mt-3">  
                {userRoles.map((entry, index) => (  
                  <div key={index} className="d-flex justify-content-between align-items-center mb-2">  
                    <div className="d-flex align-items-center">  
                      <div  
                        style={{  
                          width: 12,  
                          height: 12,  
                          backgroundColor: COLORS[index % COLORS.length],  
                          marginRight: 8,  
                          borderRadius: 2,  
                        }}  
                      />  
                      <span>{entry.name}</span>  
                    </div>  
                    <span>{entry.value}</span>  
                  </div>  
                ))}  
              </div>  
            </Card.Body>  
          </Card>  
        </Col>  
        
        <Col xl={6}>  
          <Card className="border-0 shadow-sm mb-4">  
            <Card.Header className="bg-white border-0 pt-4 pb-0">  
              <h5 className="mb-0">Daily Revenue</h5>  
            </Card.Header>  
            <Card.Body>  
              <ResponsiveContainer width="100%" height={300}>  
                <BarChart  
                  data={dailyRevenue}  
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}  
                >  
                  <CartesianGrid strokeDasharray="3 3" />  
                  <XAxis dataKey="name" />  
                  <YAxis />  
                  <Tooltip formatter={(value) => [`¥${value}`, 'Revenue']} />  
                  <Legend />  
                  <Bar dataKey="revenue" fill="#4CAF50" barSize={40} />  
                </BarChart>  
              </ResponsiveContainer>  
            </Card.Body>  
          </Card>  
        </Col>  
      </Row>  
      {/* 新增：租赁时长统计条形图 */}
      <Row className="mb-4">
        <Col xl={12}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Header className="bg-white border-0 pt-4 pb-0">
              <h5 className="mb-0">Rental Plan Statistics</h5>
            </Card.Header>
            <Card.Body>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart
                  data={rentalPlanStats}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  layout="vertical"
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="plan" type="category" />
                  <Tooltip formatter={(value, name) => name === 'totalRevenue' ? [`¥${value}`, '总收入'] : [value, '订单数']} />
                  <Legend />
                  <Bar dataKey="orderCount" fill="#2196F3" name="订单数" barSize={20} />
                  <Bar dataKey="totalRevenue" fill="#FFC107" name="总收入" barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>  
  );  
};  

export default Dashboard;