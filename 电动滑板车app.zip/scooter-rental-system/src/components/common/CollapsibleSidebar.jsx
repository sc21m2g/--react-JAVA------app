import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaChevronLeft, FaChevronRight, FaUser, FaHistory, FaWallet, FaMapMarkerAlt, FaBell, FaCog, FaQuestionCircle, FaSignOutAlt } from 'react-icons/fa';
import './CollapsibleSidebar.css';

const CollapsibleSidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const menuItems = [
    { icon: <FaUser />, text: 'User', link: '/user' },
    { icon: <FaHistory />, text: 'Ride History', link: '/history' },
    { icon: <FaWallet />, text: 'Wallet', link: '/wallet' },
    { icon: <FaMapMarkerAlt />, text: 'Nearby Scooters', link: '/nearby' },
    { icon: <FaBell />, text: 'Messages', link: '/messages' },
    { icon: <FaCog />, text: 'Account Settings', link: '/settings' },
    { icon: <FaQuestionCircle />, text: 'Help Center', link: '/help' },
    { icon: <FaSignOutAlt />, text: 'Logout', link: '/logout' }
  ];

  return (
    <div className={`collapsible-sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <button className="toggle-button" onClick={toggleSidebar}>
        {isCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
      </button>
      
      <div className="sidebar-content">
        <div className="user-section">
          <div className="user-avatar">
            <FaUser />
          </div>
          {!isCollapsed && <span className="user-name">User Center</span>}
        </div>

        <nav className="sidebar-menu">
          {menuItems.map((item, index) => (
            <Link to={item.link} key={index} className="menu-item">
              <span className="icon">{item.icon}</span>
              {!isCollapsed && <span className="text">{item.text}</span>}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default CollapsibleSidebar; 