import React from 'react';
import { Link } from 'react-router-dom';
import { FaFacebookF, FaTwitter, FaInstagram, FaWeixin, FaPhone, FaEnvelope, FaMapMarkerAlt } from 'react-icons/fa';
import logo from '../../assets/logo.svg';
import qrcode from '../../assets/qrcode.png';
import appStore from '../../assets/images/app-store.svg';
import googlePlay from '../../assets/images/google-play.svg';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="app-footer">
      <div className="footer-content">
        <div className="footer-section">
          <div className="footer-brand">
            <img src={logo} alt="ScooterGo" className="footer-logo" />
            <h3>ScooterGo</h3>
          </div>
          <p className="footer-description">
            ScooterGo致力于提供便捷、环保的城市短途出行解决方案
          </p>
          <div className="social-links">
            <a href="#" className="social-link"><FaFacebookF /></a>
            <a href="#" className="social-link"><FaTwitter /></a>
            <a href="#" className="social-link"><FaInstagram /></a>
            <div className="wechat-container">
              <a href="#" className="social-link"><FaWeixin /></a>
              <img src={qrcode} alt="WeChat QR Code" className="wechat-qrcode" />
            </div>
          </div>
        </div>

        <div className="footer-section">
          <h4>快速链接</h4>
          <ul>
            <li><Link to="/">首页</Link></li>
            <li><Link to="/scooters">查找车辆</Link></li>
            <li><Link to="/pricing">收费标准</Link></li>
            <li><Link to="/faq">常见问题</Link></li>
            <li><Link to="/about">关于我们</Link></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>法律条款</h4>
          <ul>
            <li><Link to="/terms">服务条款</Link></li>
            <li><Link to="/privacy">隐私政策</Link></li>
            <li><Link to="/refund">退款政策</Link></li>
            <li><Link to="/safety">安全指南</Link></li>
            <li><Link to="/agreement">用户协议</Link></li>
          </ul>
        </div>

        <div className="footer-section">
          <h4>联系我们</h4>
          <div className="contact-info">
            <p><FaPhone /> 110</p>
            <p><FaEnvelope /> support@scootergo.com</p>
            <p><FaMapMarkerAlt /> 西南交通大学犀浦校区</p>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="app-download">
          <h4>下载我们的APP</h4>
          <div className="app-buttons">
            <a href="#" className="app-button">
              <img src={appStore} alt="App Store" />
            </a>
            <a href="#" className="app-button">
              <img src={googlePlay} alt="Google Play" />
            </a>
          </div>
        </div>
        <div className="copyright">
          © 2024 ScooterGo | 版权所有
        </div>
      </div>
    </footer>
  );
};

export default Footer;