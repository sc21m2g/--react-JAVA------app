import React, { useState, useEffect } from 'react';  
import { Navbar, Nav, Container, Button, Dropdown, Badge } from 'react-bootstrap';  
import { Link, useNavigate, useLocation } from 'react-router-dom';  
import { FaUser, FaBell, FaSignOutAlt, FaCog, FaHistory, FaWallet } from 'react-icons/fa';  
import { useAuth } from '../../contexts/AuthContext';  
import logo from '../../assets/logo.svg';  
import './Header.css';  

const Header = () => {  
  const { user, logout, isAuthenticated } = useAuth();  
  const navigate = useNavigate();  
  const location = useLocation();  
  const [scrolled, setScrolled] = useState(false);  
  const [notifications, setNotifications] = useState([]);  

  // Track scrolling for navbar styling  
  useEffect(() => {  
    const handleScroll = () => {  
      setScrolled(window.scrollY > 50);  
    };  

    window.addEventListener('scroll', handleScroll);  
    return () => window.removeEventListener('scroll', handleScroll);  
  }, []);  

  // Mock notifications - in a real app, these would come from a backend  
  useEffect(() => {  
    if (isAuthenticated) {  
      setNotifications([  
        { id: 1, text: 'Your ride has been successfully completed', read: false, time: '10 minutes ago' },  
        { id: 2, text: 'New coupon has been added to your account', read: true, time: 'Yesterday' }  
      ]);  
    }  
  }, [isAuthenticated]);  

  const handleLogout = () => {  
    logout();  
    navigate('/login');  
  };  

  const unreadNotifications = notifications.filter(n => !n.read).length;  
  
  // Determine which nav items to show based on path  
  const isAdminPanel = location.pathname.includes('/admin');  
  
  return (  
    <Navbar   
      expand="lg"   
      fixed="top"  
      className={`${scrolled ? 'scrolled' : ''} ${isAdminPanel ? 'admin-header' : ''}`}  
      variant={isAdminPanel ? 'dark' : scrolled ? 'light' : 'dark'}  
    >  
      <Container fluid={isAdminPanel}>  
        <Navbar.Brand as={Link} to="/" className="d-flex align-items-center">  
          <img src={logo} alt="ScooterGo Logo" height="30" className="me-2" />  
          <span className="fw-bold">ScooterGo</span>  
          {isAdminPanel && <Badge bg="warning" text="dark" className="ms-2">Admin Panel</Badge>}  
        </Navbar.Brand>  

        <Navbar.Toggle aria-controls="basic-navbar-nav" />  
        <Navbar.Collapse id="basic-navbar-nav">  
          {!isAdminPanel && (  
            <Nav className="me-auto">  
              <Nav.Link as={Link} to="/" className={location.pathname === '/' ? 'active' : ''}>  
                Home
              </Nav.Link>  
              <Nav.Link as={Link} to="/scooters" className={location.pathname.includes('/scooters') ? 'active' : ''}>  
                Find Scooters
              </Nav.Link>  
              <Nav.Link as={Link} to="/pricing" className={location.pathname === '/pricing' ? 'active' : ''}>  
                Pricing
              </Nav.Link>  
              <Nav.Link as={Link} to="/about" className={location.pathname === '/about' ? 'active' : ''}>  
                About Us
              </Nav.Link>  
            </Nav>  
          )}  

          {isAdminPanel && (  
            <Nav className="me-auto">  
              <Nav.Link as={Link} to="/admin" className={location.pathname === '/admin' ? 'active' : ''}>  
                Dashboard
              </Nav.Link>  
              <Nav.Link as={Link} to="/admin/scooters" className={location.pathname.includes('/admin/scooters') ? 'active' : ''}>  
                Scooter Management
              </Nav.Link>  
              <Nav.Link as={Link} to="/admin/users" className={location.pathname.includes('/admin/users') ? 'active' : ''}>  
                User Management
              </Nav.Link>  
              <Nav.Link as={Link} to="/admin/issues" className={location.pathname.includes('/admin/issues') ? 'active' : ''}>  
                Issue Management
              </Nav.Link>  
              <Nav.Link as={Link} to="/admin/pricing" className={location.pathname.includes('/admin/pricing') ? 'active' : ''}>  
                Price Settings
              </Nav.Link>  
            </Nav>  
          )}  

          <Nav>  
            {isAuthenticated ? (  
              <>  
                {!isAdminPanel && (  
                  <Dropdown align="end" className="me-2">  
                    <Dropdown.Toggle variant="link" id="notification-dropdown" className="nav-link position-relative p-0 px-2">  
                      <FaBell />  
                      {unreadNotifications > 0 && (  
                        <Badge   
                          pill   
                          bg="danger"   
                          className="position-absolute top-0 end-0 notification-badge"  
                        >  
                          {unreadNotifications}  
                        </Badge>  
                      )}  
                    </Dropdown.Toggle>  
                    <Dropdown.Menu className="notification-dropdown">  
                      <div className="px-3 py-2 border-bottom d-flex justify-content-between align-items-center">  
                        <span className="fw-bold">Notifications</span>  
                        {notifications.length > 0 && (  
                          <Button variant="link" size="sm" className="p-0">  
                            Mark all as read  
                          </Button>  
                        )}  
                      </div>  
                      <div className="notification-scrollable">  
                        {notifications.length === 0 ? (  
                          <div className="text-center text-muted py-3">  
                            No new notifications  
                          </div>  
                        ) : (  
                          notifications.map(notification => (  
                            <Dropdown.Item   
                              key={notification.id}   
                              className={`notification-item ${notification.read ? 'read' : 'unread'}`}  
                            >  
                              <div className="d-flex justify-content-between">  
                                <span>{notification.text}</span>  
                                {!notification.read && <div className="unread-indicator"></div>}  
                              </div>  
                              <small className="text-muted">{notification.time}</small>  
                            </Dropdown.Item>  
                          ))  
                        )}  
                      </div>  
                      {notifications.length > 0 && (  
                        <div className="px-3 py-2 border-top text-center">  
                          <Link to="/notifications" className="text-decoration-none">  
                            View all  
                          </Link>  
                        </div>  
                      )}  
                    </Dropdown.Menu>  
                  </Dropdown>  
                )}  

                <Dropdown align="end">  
                  <Dropdown.Toggle variant="link" id="user-dropdown" className="nav-link d-flex align-items-center p-0 px-2">  
                    <div className="user-avatar me-2">  
                      {user?.avatarUrl ? (  
                        <img src={user.avatarUrl} alt={user.name} />  
                      ) : (  
                        <div className="default-avatar">  
                          {user?.name?.charAt(0) || user?.email?.charAt(0) || <FaUser />}  
                        </div>  
                      )}  
                    </div>  
                    <span className="d-none d-md-inline">{user?.name || 'User'}</span>  
                  </Dropdown.Toggle>  
                  <Dropdown.Menu>  
                    <Dropdown.Item as={Link} to="/profile">  
                      <FaUser className="me-2" /> Profile  
                    </Dropdown.Item>  
                    {!isAdminPanel && (  
                      <>  
                        <Dropdown.Item as={Link} to="/rentals">  
                          <FaHistory className="me-2" /> Ride History  
                        </Dropdown.Item>  
                        <Dropdown.Item as={Link} to="/wallet">  
                          <FaWallet className="me-2" /> Wallet  
                        </Dropdown.Item>  
                      </>  
                    )}  
                    <Dropdown.Item as={Link} to="/settings">  
                      <FaCog className="me-2" /> Settings  
                    </Dropdown.Item>  
                    <Dropdown.Divider />  
                    <Dropdown.Item onClick={handleLogout}>  
                      <FaSignOutAlt className="me-2" /> Logout  
                    </Dropdown.Item>  
                  </Dropdown.Menu>  
                </Dropdown>  
              </>  
            ) : (  
              <div className="d-flex align-items-center">  
                <Button   
                  variant="outline-light"   
                  className="me-2"  
                  onClick={() => navigate('/login')}  
                >  
                  Login  
                </Button>  
                <Button   
                  variant="primary"  
                  onClick={() => navigate('/register')}  
                >  
                  Register  
                </Button>  
              </div>  
            )}  
          </Nav>  
        </Navbar.Collapse>  
      </Container>  
    </Navbar>  
  );  
};  

export default Header;