import React, { useState } from 'react';
import { Form, Button, Alert, Row, Col, FormGroup } from 'react-bootstrap';
import { useAuth } from '../../contexts/AuthContext';
import feedbackService from '../../services/feedback.service';

const FeedbackForm = ({ onSuccess }) => {
  const { currentUser } = useAuth();
  const [formData, setFormData] = useState({
    type: 'OTHER',
    content: '',
    rating: 0,
    contactInfo: '',
    paymentId: ''
  });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      await feedbackService.createFeedback({
        ...formData,
        username: currentUser.username
      });
      onSuccess();
    } catch (err) {
      console.error('提交反馈失败:', err);
      setError('提交反馈失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <Form onSubmit={handleSubmit}>
      {error && <Alert variant="danger">{error}</Alert>}
      
      <Form.Group className="mb-3">
        <Form.Label>反馈类型</Form.Label>
        <Form.Select
          name="type"
          value={formData.type}
          onChange={handleChange}
          required
        >
          <option value="PAYMENT_ISSUE">支付问题</option>
          <option value="SERVICE_QUALITY">服务质量</option>
          <option value="TECHNICAL_ISSUE">技术问题</option>
          <option value="SUGGESTION">建议</option>
          <option value="COMPLAINT">投诉</option>
          <option value="OTHER">其他</option>
        </Form.Select>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>反馈内容</Form.Label>
        <Form.Control
          as="textarea"
          rows={4}
          name="content"
          value={formData.content}
          onChange={handleChange}
          placeholder="请详细描述您的问题或建议"
          required
        />
      </Form.Group>

      <Row className="mb-3">
        <Col>
          <Form.Group>
            <Form.Label>评分</Form.Label>
            <div>
              {[1, 2, 3, 4, 5].map((star) => (
                <Button
                  key={star}
                  variant={formData.rating >= star ? 'warning' : 'outline-warning'}
                  className="me-2"
                  onClick={() => setFormData(prev => ({ ...prev, rating: star }))}
                  type="button"
                >
                  ⭐
                </Button>
              ))}
            </div>
          </Form.Group>
        </Col>
        <Col>
          <Form.Group>
            <Form.Label>联系方式</Form.Label>
            <Form.Control
              type="text"
              name="contactInfo"
              value={formData.contactInfo}
              onChange={handleChange}
              placeholder="请输入您的联系方式（选填）"
            />
          </Form.Group>
        </Col>
      </Row>

      <Form.Group className="mb-3">
        <Form.Label>关联订单号</Form.Label>
        <Form.Control
          type="text"
          name="paymentId"
          value={formData.paymentId}
          onChange={handleChange}
          placeholder="请输入相关订单号（选填）"
        />
      </Form.Group>

      <Button
        variant="primary"
        type="submit"
        disabled={submitting}
        className="w-100"
      >
        {submitting ? '提交中...' : '提交反馈'}
      </Button>
    </Form>
  );
};

export default FeedbackForm;