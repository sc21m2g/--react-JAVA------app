import React, { useState, useEffect } from 'react';  
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FaBatteryThreeQuarters, FaMapMarkerAlt, FaClock, FaTools, FaWifi } from 'react-icons/fa';
import { Badge } from 'react-bootstrap';
import Map from '../common/Map';  
import ScooterService from '../../services/scooter.service';  
import '../../styles/components/ScooterDetails.css';  

const DEFAULT_COORDINATES = [30.657, 104.066]; // 成都默认坐标

const ScooterDetails = () => {  
  const { id } = useParams();  
  const navigate = useNavigate();  
  const [scooter, setScooter] = useState(null);  
  const [loading, setLoading] = useState(true);  
  const [error, setError] = useState(null);  
  const [mapCenter, setMapCenter] = useState(null);

  useEffect(() => {  
    const fetchScooterDetails = async () => {  
      try {  
        setLoading(true);  
        setError(null);
        
        if (!id) {
          throw new Error('滑板车ID不能为空');
        }
        
        const response = await ScooterService.getScooterById(id);  
        setScooter(response);  
        
        // 设置地图中心点
        if (response?.latitude && response?.longitude) {
          setMapCenter([response.latitude, response.longitude]);
        }
      } catch (err) {
        console.error('Error fetching scooter details:', err);
        setError(err.message || '获取滑板车详情失败');
      } finally {
        setLoading(false);
      }
    };  

    fetchScooterDetails();  
  }, [id]);  

  const handleRentClick = (e) => {
    e.preventDefault();
    navigate(`/scooters/${id}/rent`);
  };  
  
  const getStatusBadge = (status) => {  
    switch (status) {
      case 'AVAILABLE':  
        return <Badge bg="success">可用</Badge>;  
      case 'RENTED':
        return <Badge bg="warning" text="dark">已租出</Badge>;
      case 'MAINTENANCE':  
        return <Badge bg="danger">维护中</Badge>;  
      case 'OFFLINE':
        return <Badge bg="secondary">离线/禁用</Badge>;
      default:  
        return <Badge bg="secondary">{status}</Badge>;  
    }  
  };  
  
  const getStatusIcon = (status) => {
    switch (status) {
      case 'RENTED':
        return <FaClock className="status-icon rented" />;
      case 'MAINTENANCE':
        return <FaTools className="status-icon maintenance" />;
      case 'OFFLINE':
        return <FaWifi className="status-icon offline" />;
      default:
        return null;
    }
  };

  const getRentButtonConfig = (status) => {
    switch (status) {
      case 'AVAILABLE':
        return {
          text: '立即租用',
          disabled: false,
          style: {
            backgroundColor: '#007bff',
            opacity: 1
          }
        };
      case 'RENTED':
        return {
          text: '已被租用',
          disabled: true,
          style: {
            backgroundColor: '#ffc107',
            color: '#212529',
            opacity: 0.8
          }
        };
      case 'MAINTENANCE':
        return {
          text: '维护中',
          disabled: true,
          style: {
            backgroundColor: '#dc3545',
            opacity: 0.8
          }
        };
      case 'OFFLINE':
        return {
          text: '暂不可用',
          disabled: true,
          style: {
            backgroundColor: '#6c757d',
            opacity: 0.8
          }
        };
      default:
        return {
          text: '不可用',
          disabled: true,
          style: {
            backgroundColor: '#6c757d',
            opacity: 0.8
          }
        };
    }
  };  

  if (loading) {  
    return (  
      <div className="loading-container">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">加载中...</span>
        </div>
        <p>正在加载滑板车信息...</p>
      </div>
    );
  }

  if (error) {
    return (  
      <div className="error-container">
        <h3>出错了</h3>
        <p>{error}</p>
        <Link to="/scooters" className="btn btn-primary">
            返回滑板车列表  
        </Link>
        </div>  
    );  
  }  

  if (!scooter) {
  return (  
      <div className="error-container">
        <h3>未找到滑板车</h3>
        <p>无法找到ID为 {id} 的滑板车</p>
        <Link to="/scooters" className="btn btn-primary">
          返回滑板车列表
        </Link>
      </div>  
    );
  }

  const buttonConfig = getRentButtonConfig(scooter.status);

  return (
    <div className="scooter-details-container">
      {/* 顶部导航栏 */}
      <div className="details-header">
        <Link to="/scooters" className="back-link">
          ← 返回列表
        </Link>
        <button
          onClick={handleRentClick}
          disabled={buttonConfig.disabled}
          style={{
            ...buttonConfig.style,
            padding: '8px 20px',
            borderRadius: '4px',
            border: 'none',
            cursor: buttonConfig.disabled ? 'not-allowed' : 'pointer'
          }}
        >
          {buttonConfig.text}
        </button>
          </div>  
          
      {/* 车辆信息卡片 */}
      <div className="scooter-info-card">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h5 className="mb-0">{scooter.model}</h5>
          {getStatusBadge(scooter.status)}
                </div>  
        <div className="info-grid">
          <div className="info-item">
            <FaMapMarkerAlt className="info-icon location" />
            <span>当前位置：{scooter.location || '未知位置'}</span>
          </div>  
          <div className="info-item">
            <FaBatteryThreeQuarters className={`info-icon battery-${scooter.batteryLevel >= 70 ? 'high' : scooter.batteryLevel >= 30 ? 'medium' : 'low'}`} />
            <span>电池电量：{scooter.batteryLevel || 0}%</span>
                  </div>  
          {getStatusIcon(scooter.status) && (
            <div className="info-item">
              {getStatusIcon(scooter.status)}
              <span>{buttonConfig.text}</span>
                </div>  
              )}  
                    </div>  
                  </div>  
                  
      {/* 地图区域 */}
      <div className="map-container">
        {mapCenter && (
          <Map
            height="100%"
            center={mapCenter}
            zoom={15}
            showControls={true}
            markers={[{
              position: mapCenter,
              scooter: scooter
            }]}
            selectedScooterId={scooter.id}
          />
                            )}  
                          </div>  
                        </div>  
  );  
};  

export default ScooterDetails;